﻿using JonSkeet.DemoUtil;

namespace Chapter06
{
    class Program
    {
        static void Main(string[] args)
        {
            ApplicationChooser.Run();
        }
    }
}