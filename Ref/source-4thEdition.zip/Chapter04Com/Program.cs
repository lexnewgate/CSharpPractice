﻿using JonSkeet.DemoUtil;

namespace Chapter04Com
{
    class Program
    {
        static void Main(string[] args)
        {
            ApplicationChooser.Run();
        }
    }
}
