﻿using JonSkeet.DemoUtil;

namespace Chapter03
{
    class Program
    {
        static void Main(string[] args)
        {
            ApplicationChooser.Run();
        }
    }
}
