﻿using JonSkeet.DemoUtil;

namespace Chapter14
{
    class Program
    {
        static void Main(string[] args)
        {
            ApplicationChooser.Run();
        }
    }
}