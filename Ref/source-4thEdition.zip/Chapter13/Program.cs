﻿using JonSkeet.DemoUtil;

namespace Chapter13
{
    class Program
    {
        static void Main(string[] args)
        {
            ApplicationChooser.Run();
        }
    }
}