﻿using JonSkeet.DemoUtil;

namespace Chapter15
{
    class Program
    {
        static void Main(string[] args) => ApplicationChooser.Run();
    }
}
