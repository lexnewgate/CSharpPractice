﻿using JonSkeet.DemoUtil;

namespace Chapter04
{
    class Program
    {
        static void Main(string[] args)
        {
            ApplicationChooser.Run();
        }
    }
}
